$(document).ready(function(){
/////////////////////////////////////////////////////////////////////////////////////
// NAvigation
 $( document ).tooltip();

// navigation
$('.special-visu li:has(ul)')
  .addClass('has-subnav')
  .each(function(){
    var $li = $(this)
    , $a = $('> a', $li);

    $a.on('mouseenter', function(){
      $li.addClass('active');
      $li.children(".sub-nav").slideDown();
    });
    $li.on('mouseleave', function(){
      $li.removeClass('active');
      $li.children(".sub-nav").slideUp();
    });
  });



//////////////////////////////////////////////////////////////////////////////////////
/// Pour les poingner de resizes
      /*  $(".variantes").resizable({
            handleSelector: ".splitterA",
            resizeHeight: false
        });
        $(".texte-oeuvre").resizable({
            handleSelector: ".splitterB",
            resizeHeight: false
        });
         $(".notes-ouvres").resizable({
            handleSelector: ".splitterC",
            resizeHeight: false
        });
         $(".annotations").resizable({
            handleSelector: ".splitterD",
            resizeHeight: false
        });*/

//////////////////////////////////////////////////////////////////////////////////////
/// Pour les variantes surligner en rose
      //var manique = $(this).prev(".main-visu");
      /*$(".variante").hover( 
        function() {
          $(this).addClass("pink");
          $(this).prev(".main-visu").children("img").addClass("pink");
          $($(this).data("target")).addClass("pink");
        }, function() {
          $(this).removeClass("pink");
          $(this).prev(".main-visu").children("img").removeClass("pink");
          $($(this).data("target")).removeClass("pink");
        }
      );
      $(".main-visu img").hover(
        function() {
          $(this).addClass("pink");
          $(this).parent(".main-visu").next(".variante").addClass("pink");
          $($(this).parent(".main-visu").next(".variante").data("target")).addClass("pink");
        }, function() {
          $(this).removeClass("pink");
          $(this).parent(".main-visu").next(".variante").removeClass("pink");
          $($(this).parent(".main-visu").next(".variante").data("target")).removeClass("pink");
        }
      );*/
      



      /// Surligner DES CLASS IDENTIQUE les variantes par exemples

      
        $("[class*=variante-]").hover(
          function() {
             $('.variante-'+ this.className.match(/\d+/) ).each(function( i ){
                $(this).addClass("highlight"); 
             })
            
                      
        }, function (){
            $('.variante-'+ this.className.match(/\d+/) ).each(function( i ){
                $(this).removeClass("highlight"); 
            })
        });


        $("[class*=note-]").hover(
          function() {
             $('.note-'+ this.className.match(/\d+/) ).each(function( i ){
                $(this).addClass("highlight"); 
             })              
        }, function (){
            $('.note-'+ this.className.match(/\d+/) ).each(function( i ){
                $(this).removeClass("highlight"); 
            })
        });


        $("[class*=annotation-]").hover(
          function() {
             $('.annotation-'+ this.className.match(/\d+/) ).each(function( i ){
                $(this).addClass("highlight"); 
             })                      
        }, function (){
            $('.annotation-'+ this.className.match(/\d+/) ).each(function( i ){
                $(this).removeClass("highlight"); 
            })
        });
      

//////////////////////////////////////////////////////////////////////////////////////
/// Pour les notes de montesquieu qui apparaissent au scroll

    ///////
    //      Work on on widow with one scroll, the window scroll
    //////
    var clientHeight = $( window ).height();
      $('.content-visu').css('height', clientHeight - 50);

    //////////////////// 
    //var scrollWhere = 0;
    $(".texte-oeuvre .content-visu").scroll(function(){
      $('.appel-note-montesquieu, .appel-annotation').each(function(){
        if(isScrolledIntoView($(this),scrollWhere)){
          $($(this).data("target")).show();
        }
        else{
          $($(this).data("target")).hide();
        }
      });
    });


   
    ////////////////////////////

    //var contentHeight = $( ".content-visu" ).height();
      //$('.texte-oeuvre .content-visu').css('height', clientHeight);
    /////

    function isScrolledIntoView(elem, windowTop){
        var $elem = $(elem);
        var $window = $(window);

        //console.log(windowTop); 
        var docViewTop = $window.scrollTop() + 210 - windowTop;
        var docViewBottom = docViewTop + $window.height();

        var elemTop = $elem.offset().top;
        var elemBottom = elemTop + $elem.height();

        $(window).on('scroll', function() {
          topOffset = $(this).scrollTop() ;
          elemTop =   topOffset - docViewTop;
          //console.log(scrollWhere); 
        });
        return ((elemBottom <= docViewBottom) && (elemTop >= docViewTop));

    }

   //////////////////////////////////////////////////////////////////////////////////////
/// Pour détacher, ratacher les fenêtres de visu

    $(".popin").click(function(){
      if ($(this).parents("article").hasClass( "pop" )){
          $(this).parents("article").removeClass("pop").removeAttr("style").draggable({
          revert: true,
          containment: "body"
         });
          $(this).children("img").attr({
            src: "img/icone-move.png",
            alt: "Détacher le fenêtre"
          });
          $(this).siblings(".close").children("img").attr({
            src: "img/icone-moins.png",
            alt: "Reduire la fenêtre"
          });  
      }else{
        $(this).addClass("haspop").parents("article").addClass("pop").css({"position": "absolute", "top":"-10px", "right":"40px", "z-index":"20", "cursor" : "grab" }).draggable({
          revert: false,
          containment: "body"

         });

        $(this).children("img").attr({
          src: "img/icone-aimant.png",
          alt: "Ratacher le fenêtre"
        });
        $(this).parents("article").removeClass("bloc-hidden");
        $(this).siblings(".close").children("img").attr({
            src: "img/icone-moins.png ",
            alt: " "
          });     
      }
    });


   //////////////////////////////////////////////////////////////////////////////////////
/// Pour reduire les onglets de la visu
    $(".close").click(function(){
      if ($(this).parents("article").hasClass( "bloc-hidden" )){
        $(this).parents("article").removeClass("bloc-hidden").css({width: "20%;" });
        //$(this).text("—");
        $(this).children("img").attr({
          src: "img/icone-moins.png",
          alt: "Reduire la fenêtre"
        });

      }else{
        $(this).parents("article").addClass("bloc-hidden").css({width: "37px" });
        //$(this).text("+");
        $(this).children("img").attr({
          src: "img/icone-plus.png",
          alt: "Voir la fenêtre"
        });


       /* $(this).next().children("img").attr({
          src: "img/icone-in.png",
          alt: "Ratacher le fenêtre"
        });*/
      }
    });


  //////////////////////////////////////////////////////////////////////////////////////
/// Pour pouvoir redimensionner les onglet de la visu
    $( function() {
      $( ".resizable" ).resizable();
    });


      $(function(){
         $('.supLettres').on('change',function(){
            $('#formSupLettres').submit();
            alert ("Pour l'instant cette fonctionnalité n'est pas disponible.  Merci de votre compréhention.")
            });
        });



      // POPUP du menu
/*$('.popup').each(function() {
    var $link = $(this);
    var $dialog = $('<div></div>')
      .load($link.attr('href'))
      .dialog({
        autoOpen: false,
        title: $link.attr('title'),
        width: 500,
        height: 300
      });
 
    $link.click(function() {
      $dialog.dialog('open');
 
      return false;
    });
  });*/

});// fin de doc ready


 
//function scrollWhere(elem) {
var $window = $(window);
 
$(window).on('scroll', function() {
    scrollWhere = $(this).scrollTop();
 
    //console.log(scrollWhere);
   // return( $topOffset);
 
});
//}

///////////////////
/*
ZOOM MANUSCRIT PUR JS
*/


(function () {
  function hasTouch() {
      return 'ontouchstart' in document.documentElement;
  }
  var img_ele = null,
      event_start = hasTouch() ? 'touchstart' : 'mousedown',
      event_move = hasTouch() ? 'touchmove' : 'mousemove',
      event_end = hasTouch() ? 'touchend' : 'mouseup';
      console.log(event_start + "|" + event_move + "|" + event_end);
  (function () {
    function zoom(zoomincrement) {
      img_ele = document.getElementById('drag-img');
      var pre_width = img_ele.getBoundingClientRect().width,
          pre_height = img_ele.getBoundingClientRect().height;
      img_ele.style.width = (pre_width * zoomincrement) + 'px';
      img_ele.style.height = (pre_height * zoomincrement) + 'px';
      img_ele = null;
    }
    document.getElementById('zoomout').addEventListener('click', function() {
      zoom(0.5);
    });
    document.getElementById('zoomin').addEventListener('click', function() {
      zoom(1.5);
    }); 
  }());
  (function () {  
    function start_drag(event) {
      var x_cursor = hasTouch() ? event.changedTouches[0].clientX : event.clientX,
          y_cursor = hasTouch() ? event.changedTouches[0].clientY : event.clientY;
      img_ele = this;     
      x_img_ele = x_cursor - img_ele.offsetLeft;
      y_img_ele = y_cursor - img_ele.offsetTop;
      console.log("start drag");
    }
    function stop_drag() {
      img_ele = null;
      console.log("stop drag");
    }
    function while_drag(event) {
      var x_cursor = hasTouch() ? event.changedTouches[0].clientX : event.clientX,
          y_cursor = hasTouch() ? event.changedTouches[0].clientY : event.clientY;
      if (img_ele !== null) {
        img_ele.style.left = (x_cursor - x_img_ele)  + 'px';
        img_ele.style.top = (y_cursor - y_img_ele) - 36 +'px';  /// A changer en fonction de la hauteur du bandeau, sinon ça fait un décalage au mouvement
        console.log('dragging > img_left:' + img_ele.style.left + ' | img_top: ' + img_ele.style.top);
      }
    }   
  document.getElementById('drag-img').addEventListener(event_start, start_drag);
  document.getElementById('content-img').addEventListener(event_move, while_drag);
  document.getElementById('content-img').addEventListener(event_end, stop_drag);
  }());
}());
  
  